// 有多少import多少
import menber from './menber/index'
import common from './common/index'
import sys from './sys/index'
import students from './students/index'
import teacher from './teacher/index'
import operation from './operation/index'
export default {
    menber,common,sys,students,teacher,operation
}