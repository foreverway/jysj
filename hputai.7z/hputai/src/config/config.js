const baseUrl = 'http://personal.test.hqjystudio.com'
const phone='123456789'
// const student_url='http://vue.test.hqjystudio.com/school/#/' //测试链接
const student_url='http://newstudent.hqjystudio.com/school/#/'

export default {
  
    baseUrl,
    phone,
    student_url
}