'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"http://personal.test.hqjystudio.com"'   //线上请求前缀,正式去掉test.
}

